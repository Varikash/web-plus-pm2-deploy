export const { JWT_SECRET = 'JWT_SECRET' } = process.env;
export const { DB_ADDRESS = 'mongodb://localhost:27017/mestodb' } = process.env;
